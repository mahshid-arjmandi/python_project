
class Employee:
      hoursSalary=43000
      housing=700000000
      childs=1000000
      marriage=2000000
      def __init__(self,firstName_,lastName_,age_,stateMarriage_,numberChilds_):
          self.firstName=firstName_
          self.lastName=lastName_
          self.age=age_
          self.numberChilds=numberChilds_
          self.stateMarriage=stateMarriage_


      def set_info(self,workHoursNumber_):
          self._workHoursNumber=workHoursNumber_

      def get_info(self):
          return self._workHoursNumber

      def salary(self):
           return self._workHoursNumber*(Employee.hoursSalary)

      def __lt__(self,object):
             if(self.age<object.age):
                  return f"The age of employee 1 is younger than employee 2:{self.age}<{object.age}"
             elif(self.age==object.age):
                  return f"The age of two employees is the same:{self.age}={object.age}"
             else:
                  return f"The age of employee 1 is older than employee 2:{self.age}>{object.age}"
      def __str__(self):
            print("________________________________________________________________________")
            print("\t\t\t information Employee")
            print("________________________________________________________________________")
            return f"FirstName:{self.firstName}\t\tLastName:{self.lastName}\t\tAge:{self.age}\n\nnumber_Of_Childs:{self.numberChilds}\t\tStatuse_Marriage:{self.stateMarriage}\t\tSalary_Payment:{self.salary()}"
            
'''
firstName__=input("Please,enter FirstName:")
lastName__=input("Please,enter lastName:")
age__=int(input("The age of the employee:"))
stateMarriage__=input("Specify whether you are married or single:(married or single?)")
numberChids__=int(input("number of children:"))
e1=Employee(firstName__,lastName__,age__,stateMarriage__,numberChids__)
workHoursNumber__=int(input("please,enter the number of working hours of the employee?"))
e1.set_info(workHoursNumber__)
print(e1)

firstName__=input("Please,enter FirstName:")
lastName__=input("Please,enter lastName:")
age__=int(input("The age of the employee:"))
stateMarriage__=input("Specify whether you are married or single:(married or single?)")
numberChids__=int(input("number of children:"))
e2=Employee(firstName__,lastName__,age__,stateMarriage__,numberChids__)
workHoursNumber__=int(input("please,enter the number of working hours of the employee?"))
e2.set_info(workHoursNumber__)
print(e1<e2)'''

class OfficialEmployee(Employee):
      def __init__(self,firstName_,lastName_,age_,stateMarriage_,numberChilds_):
          super(). __init__(firstName_,lastName_,age_,stateMarriage_,numberChilds_)

      def set_info(self,workHoursNumber_):
          super().set_info(workHoursNumber_)
           

      def get_info(self):
          super().get_info()    

      def salary(self):
           return super().salary()

      def __lt__(self,object):
            return super().__lt__(object)
            
      def __str__(self):
          return super().__str__()

firstName__=input("Please,enter FirstName:")
lastName__=input("Please,enter lastName:")
age__=int(input("The age of the employee:"))
stateMarriage__=input("Specify whether you are married or single:(married or single?)")
numberChids__=int(input("number of children:"))
o1=OfficialEmployee(firstName__,lastName__,age__,stateMarriage__,numberChids__)
workHoursNumber__=int(input("please,enter the number of working hours of the employee?"))
o1.set_info(workHoursNumber__)
print(o1)

firstName__=input("Please,enter FirstName:")
lastName__=input("Please,enter lastName:")
age__=int(input("The age of the employee:"))
stateMarriage__=input("Specify whether you are married or single:(married or single?)")
numberChids__=int(input("number of children:"))
o2=Employee(firstName__,lastName__,age__,stateMarriage__,numberChids__)
workHoursNumber__=int(input("please,enter the number of working hours of the employee?"))
o2.set_info(workHoursNumber__)
print(o1<o2)  

class UnofficialEmployee(Employee):
      def __init__(self,firstName_,lastName_,age_,stateMarriage_,numberChilds_):
          super(). __init__(firstName_,lastName_,age_,stateMarriage_,numberChilds_)

      def set_info(self,workHoursNumber_):
          super().set_info(workHoursNumber_)

      def get_info(self):
          super().get_info()    

      def salary(self):
           self.total=self._workHoursNumber*(Employee.hoursSalary)
           if(self.numberChilds==0 and self.stateMarriage=="married"):
               self.salaryPayment=self.total+Employee.housing+Employee.marriage
               return self.salaryPayment
           elif(self.numberChilds==0 and self.stateMarriage=="single"):
                 self.salaryPayment=self.total+Employee.housing
                 return self.salaryPayment
           elif(self.stateMarriage=="married" and self.numberChilds!=0):
                 self.salaryPayment=self.total+Employee.housing+Employee.marriage+Employee.marriage+(Employee.childs)*(self.numberChilds)
                 return self.salaryPayment
      def __lt__(self,object):
            return super().__lt__(object)

      def __str__(self):  
          return super().__str__()

'''
firstName__=input("Please,enter FirstName:")
lastName__=input("Please,enter lastName:")
age__=int(input("The age of the employee:"))
stateMarriage__=input("Specify whether you are married or single:(married or single?)")
numberChids__=int(input("number of children:"))
u1=UnofficialEmployee(firstName__,lastName__,age__,stateMarriage__,numberChids__)
workHoursNumber__=int(input("please,enter the number of working hours of the employee?"))
u1.set_info(workHoursNumber__)
print(u1)
'''
         
