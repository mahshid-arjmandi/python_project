#parent class

class Student:
    #Numberlessons=>tedad e dorous akhz shodeh tavasote daneshjou.
    def  __init__(self,firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_):
         self.firstName=firstName_
         self.lastName=lastName_
         self.studentNumber=studentNumber_
         self.numberLessons=numberLessons_
         self.yearEntrance=yearEntrance_
         self.lessonsNameList=list()


    
        
         #Daryafte name dorouse akhz shodeh va zakhireh un dar lessonsNamelist.
         #baraye mesal=>lessonNameList=[math,progrmming,...]
    def receive_lessons_name(self):      
         for index in range(0,self.numberLessons):
             lessonName=input("Please,enter the name of the lesson:")
             self.lessonsNameList.append(lessonName)

         
         #ijad yek dictionary ke shamele etelaate (tedad vahed,mark) har dars mibashad.
         #lessonsInfoDict={"lessonsnameList[0]":lessonUnitAndMarkDict,...}
         #lessonInfoDict={"math":{unit:3,marks:20,},...}
         self.lessonsInfoDict=dict()
         self.lessonsInfoDict.fromkeys(self.lessonsNameList) 

         #ijade yek dictionary ke shamele keys unit and mark mibashad.
         #baraye mesal=>lessonUnitAndMarkDict={"unit":3,"mark":20}
         self.lessonUnitAndMarkDict=dict()
         self.lessonUnitAndMarkDict.fromkeys(("unit","mark"))

         #vared kardane tedad vahed dorous.
         for index in range(0,len(self.lessonsNameList)):
              unit=int(input(f"Please,Enter the number of  {self.lessonsNameList[index]} units."))
              self.lessonUnitAndMarkDict["unit"]=unit

              mark=float(input(f"Please,Enter {self.lessonsNameList[index]} score obtained."))
              self.lessonUnitAndMarkDict["mark"]=mark

              self.lessonUnitAndMarkDictCopy=(self.lessonUnitAndMarkDict).copy()

              #ezafeh kardan etelaat dars.
              self.lessonsInfoDict[self.lessonsNameList[index]]=self.lessonUnitAndMarkDictCopy
              self.lessonUnitAndMarkDict.clear()
              
         return self.lessonsInfoDict    

    #mohasebeh majmoue vahedhaye pass shodeh.
    def units_sum(self):
         #baresi inke nomreh kasb shodeh balaye 10 bashad.
         self.unitsNumberSum=0
         for lesson in self.lessonsNameList: 
             if(self.lessonsInfoDict[lesson]["mark"]>=10):
                 self.unitsNumberSum=self.unitsNumberSum+self.lessonsInfoDict[lesson]["unit"]           
         return self.unitsNumberSum

   
    #mohasebeh moadel.
    def average_computing(self):
         marksSum=0 
         for i in (self.lessonsNameList):
             marksSum=marksSum+(self.lessonsInfoDict[i]["mark"])
         self.ave=marksSum/len(self.lessonsNameList)
         return self.ave

    
    #check kardan vaziat fareghol tahsili.
    #tedad vahed akhz shodeh=numberUnit
    def graduated(self):
        if(self.ave>=12 and self.unitsNumberSum==140):
            return "graduated."
        else:
            return "not graduated."

    def __lt__(self,object):
        if(self.yearEntrance<object.yearEntrance):
            return f"{self.yearEntrance}<{object.yearEntrance}" 
        elif(self.yearEntrance==object.yearEntrance):
            return f"{self.yearEntrance}={object.yearEntrance}"
        else:
            return f"{self.yearEntrance}>{object.yearEntrance}"
    #chap kardan vaziate daneshjou.
    def __str__(self):
        print("_____________________________________________________________________________________")
        print("\t\t\t  Student_Information")
        print("_____________________________________________________________________________________")
        return(
            f"First_name:{self.firstName}\t\tLast_name:{self.lastName}\t\tstudentNumber:{self.studentNumber}\t\tYear of entering the university:{self.yearEntrance}\t\tTotal units obtained:{self.units_sum()}\t\tAvrage:{self.average_computing()}\t\tGraduation status:{self.graduated()}")

#==============================================
#Bachelor student
class Bachelor(Student):
#lesson={"nameLesson":[mark,vahed],...}
#Numberlessons=>tedad e dorous akhz shodeh tavasote daneshjou.
    def  __init__(self,firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_):
         super().__init__(firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_)
 
    def receive_lessons_name(self): 
        super().receive_lessons_name()    
    #mohasebeh moadel.
    def average_computing(self):
         return super().average_computing()

    #mohasebeh majmoue vahedhaye pass shodeh.
    def units_sum(self):
         #baresi inke nomreh kasb shodeh balaye 10 bashad.
         return super().units_sum()
             
    #check kardan vaziat fareghol tahsili.
    #tedad vahed akhz shodeh=numberUnit
    def graduated(self):
        return super().graduated()

    def __lt__(self,object):
        return super().__lt__(object) 

    #chap kardan vaziate daneshjou.
    def __str__(self):
        return super().__str__()
        
                                           
          
firstName__=input("please,enter studentFirstName:")  
lastName__=input("please,enter studentLastName:")
studentNumber__=int(input("please,enter StudentNumber:"))
yearEntrance__=int(input("please,enter the year of entering the university:"))
#NumberLessons=>tedad e dorous akhz shodeh tavasote daneshjou.
numberLessons__=int(input("Please,enter the number of lessons taken by the student:"))

b=Bachelor(firstName__,lastName__,studentNumber__,numberLessons__,yearEntrance__)
b.receive_lessons_name()
b.average_computing()
b.units_sum()
print(b)
firstName__=input("please,enter studentFirstName:")  
lastName__=input("please,enter studentLastName:")
studentNumber__=int(input("please,enter StudentNumber:"))
yearEntrance__=int(input("please,enter the year of entering the university:"))
#NumberLessons=>tedad e dorous akhz shodeh tavasote daneshjou.
numberLessons__=int(input("Please,enter the number of lessons taken by the student:"))
b1=Bachelor(firstName__,lastName__,studentNumber__,numberLessons__,yearEntrance__)
b1.receive_lessons_name()
b1.average_computing()
b1.units_sum()

print(b<b1)
    
#===========================

#MastersYear of University entrance
class Masters(Student):

#lesson={"nameLesson":[mark,vahed],...}
#Numberlessons=>tedad e dorous akhz shodeh tavasote daneshjou.
    def  __init__(self,firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_):
         super().__init__(firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_)
         (self.lessonsNameList).append("Thesis")

    def receive_lessons_name(self):
        return super().receive_lessons_name()
        
    #mohasebeh moadel.
    def average_computing(self):
         return super().average_computing()

    #mohasebeh majmoue vahedhaye pass shodeh.
    def units_sum(self):
         #baresi inke nomreh kasb shodeh balaye 10 bashad.
         return super().units_sum()
              
    #check kardan vaziat fareghol tahsili.
    #tedad vahed akhz shodeh=numberUnit
    def graduated(self):
        if(self.ave>=14 and self.unitsNumberSum==24 and self.lessonsInfoDict["Thesis"]["mark"]>=12):
            return "graduated."
        else:
            return "not graduated."

    def __lt__(self,object):
        return super().__lt__(object)

    #chap kardan vaziate daneshjou.
    def __str__(self):
        return super().__str__()
        
        
        
                                           
'''          
#firstName__=input("please,enter studentFirstName:")  
#lastName__=input("please,enter studentLastName:")
#studentNumber__=int(input("please,enter StudentNumber:"))
#yearEntrance__=int(input("please,enter the year of entering the university:"))
#NumberLessons=>tedad e dorous akhz shodeh tavasote daneshjou.
#numberLessons__=int(input("Please,enter the number of lessons taken by the student:"))

#s=Masters(firstName__,lastName__,studentNumber__,numberLessons__,yearEntrance__)
#s.receive_lessons_name()
#s.average_computing()
#s.units_sum()
#s.graduated()
#print(s)    
'''          
#===========================
#PHD
#lesson={"nameLesson":[mark,vahed],...}
class Phd(Student):
    def  __init__(self,firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_):
         super().__init__(firstName_,lastName_,studentNumber_,numberLessons_,yearEntrance_)
         (self.lessonsNameList).append("Thesis")

    def receive_lessons_name(self):
        return super().receive_lessons_name()
        
    #mohasebeh moadel.
    def average_computing(self):
         return super().average_computing()

    #mohasebeh majmoue vahedhaye pass shodeh.
    def units_sum(self):
         #baresi inke nomreh kasb shodeh balaye 10 bashad.
         return super().units_sum()

    #taein vaziat payannameh tavasoteh ostad rahnama.
    def teacher_approval(self):
        self.stateApproval=input("Has the thesis been approved by the supervisor?(yes or no)")  
              
    #check kardan vaziat fareghol tahsili.
    #tedad vahed akhz shodeh=numberUnit
    def graduated(self):
        if(self.ave>=16 and self.unitsNumberSum==18 and self.lessonsInfoDict["Thesis"]["mark"]>=12 and self.stateApproval=="yes"):
        
            return "graduated."
        else:
            return "not graduated."

    def __lt__(self,object):
         super().__lt__(object)
         

    #chap kardan vaziate daneshjou.
    def __str__(self):
        return super().__str__()
        
        
        
                                           
'''         
#firstName__=input("please,enter studentFirstName:")  
#lastName__=input("please,enter studentLastName:")
#studentNumber__=int(input("please,enter StudentNumber:"))
#yearEntrance__=int(input("please,enter the year of entering the university:"))
#NumberLessons=>tedad e dorous akhz shodeh tavasote daneshjou.
#numberLessons__=int(input("Please,enter the number of lessons taken by the student:"))

'''
#p=Phd(firstName__,lastName__,studentNumber__,numberLessons__,yearEntrance__)
#p.receive_lessons_name()
#p.average_computing()
#p.units_sum()
#p.teacher_approval()
#p.graduated()
#print(p) '''  
#=================




 



