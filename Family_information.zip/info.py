#hadaf khandan etelaate khanevadeh az file  va zakhireh un dar dictionary mibashad.
#f_el_list=['First_name','Last_name','Birth_Day',...]
#family_Dict={"member_1":{},"member_2":{},"member_3":{}}
#info_Dict={"First_name":values[0],"Last_name":values[1],"Birth_Day":values[2],"weight":values[3],"height":values[4]}
#values=['','','','']

def recive__name__(Name):
    global count,s
    count=1#aya name daryafti ozve khanevadeh hast ya kheyr.
    s=0#be komak s moshakhas mikonim aya etelaate shakhsi sabt shodeh ast ya kheyr.
    for m in family_Dict:#m=member_1,member_2,...
        for r in family_Dict[m]:#r=family_Dict['member_1']=info={'First_name':,'Last_name':,'Birth_Day':,'weight':,'height'}
            D=family_Dict[m].copy()
            w=family_Dict[m].copy()
        #print(family_Dict[c])
            if D[r]==Name:#moshakhas kardan inke Aya "Name" made nazar ozve khanevadeh hast ya kheyr.
           #D[r]=>r={'member_1','member_2',...} 
               count+=1
               for l in family_Dict[m]:#l=family_Dict['member_1']=info={'First_name':'','Last_name':,'Birth_Day':,'weight':,'height'}
                   if D[l]=='':#taeein inke aya information shakhs sabt shodeh ast ya kheyr.
                           #D[l]=>l='First_name','last_name',... .
                      s+=1   
                   else:
                       pass
               print(f"Family_member_Information:",D,"\n")      
                  
            else:
               continue 
    return (count,s); 

def _state_(Count,S):
    if Count>1:#if member made nazar ozve in khanevadeh bashad.
       pass
    else:#member made nazar ozve in khanevadeh nemibashad.
        print(f"__{Name}__ isn't a member of this family.")
    if S==4:#if etelaateh member made nazar sabt nashodeh bashad.
       print(f"!!!Sadly the information of this family member (__{Name}__) has not been registered.")
    elif(s!=0):#if etelaate shakhs be sourate naghes sabt shodeh ast message zir namayesh dadeh shavad.
        print(f"The information of this family member (__{Name}__) is not fully recorded.")
    else:#if etelsste member made nazar sabt shodeh bashad.
       pass

f_el_list=[]
keys=[]
values=[]
family_Dict=dict()
member_list=[]
a=5
b=a+5
n=0#tedad satr file ke ba tavajoh be un tedade members family be dast khahad amad.
for line  in open('D:\\test_flie\\information.txt'):
    for z in line.split(","):#z=line.split(",")=>z=First_name,Last_name,...        
        f_el_list.append(z)
    n+=1    
for x in f_el_list:
    if x=='\n':
       f_el_list.remove(x)
    else:
      pass                  
for k in range(0,5,1):#ijade listi az attributes=>First_name,Last_name,height,weight
        keys.append(f_el_list[k])  
for z in range(1,n,1):#n=>tedade satr file be joz satr aval.n+1
    member_list.append(f"member_{z}")
family_Dict=family_Dict.fromkeys(member_list)    
values=[]
#be tedada members khanevadeh bayad Dictionary(info) ijad shavad.
for i in range(0,n-1,1):#k tedade satr haei ast ke shamele etelaate member ha mibashad.
    for j in range(a,b,1):#list_a shamele etelaate khandeh shodeh az file mibashad peymayesh kardeh albate az akharin attribute ta 5 ta member badi.
        values.append(f_el_list[j])#values=['sara','samaei','1399/10/23','45','160']
    info=dict(zip(keys,values))
    info_new=info.copy()
    t=i
    family_Dict[member_list[t]]=info_new
    info.clear()
    values.clear()
    a=a+5
    b=a+5
print('Family_Information:',family_Dict,"\n")
Name=input("please,enter name:")
Count,S=recive__name__(Name)
_state_(Count,S)
        
    
